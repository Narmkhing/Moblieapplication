import 'package:flutter/material.dart';
import '../controller/category_controller.dart';
import 'package:get/get.dart';

class FavPage extends StatelessWidget {
  const FavPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final CathController cathController = Get.put(CathController());
    cathController.getFav();

    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: const Icon(Icons.arrow_back),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Obx(() => cathController.yogaModels.isEmpty
              ? const Center(
                  child: Text("No data"),
                )
              : ListView.builder(
                  itemBuilder: (context, index) {
                    return Card(
                      child: Column(
                        children: [
                          Text(cathController.yogaModels[index].englishName ??
                              ""),
                        ],
                      ),
                    );
                  },
                  itemCount: cathController.yogaModels.length,
                )),
        ),
      ),
    );
  }
}
